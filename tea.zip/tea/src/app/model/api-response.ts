export interface ApiResponseTransStatus {
	fundid: string;
	cstatus: string;
	description: string;
	ncount: number;
}
