export { SpeechModule } from './module';
export { SpeechService } from './speech.service';
export { SpeechActionDirective } from './speech-action.directive';
export { SpeechContextDirective } from './speech-context.directive';
