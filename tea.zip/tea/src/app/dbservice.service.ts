import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class DbserviceService {
private REST_API_SERVER = "http://localhost:8080/tea/userdetails";
private REST_API_SERVER_TRANS = "http://localhost:8080/tea/transactionStatus";

  constructor(private httpClient: HttpClient) { }
  public sendGetRequest(username: String){
      return this.httpClient.post(this.REST_API_SERVER,username);
    }

    public getTransactionstatus(){
          return this.httpClient.get(this.REST_API_SERVER_TRANS);
        }
}
