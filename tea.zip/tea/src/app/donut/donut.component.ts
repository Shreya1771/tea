import { Component, OnInit } from '@angular/core';
import d3 from 'd3';
import 'ag-grid-community/dist/styles/ag-grid.css';
import 'ag-grid-community/dist/styles/ag-theme-balham.css';
import { DbserviceService } from '../dbservice.service';
import { ApiResponseTransStatus } from '../../app/model/api-response';
import {GridReadyEvent,ColDef,} from 'ag-grid-community'
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-donut',
  templateUrl: './donut.component.html',
  styleUrls: ['./donut.component.css']
})
export class DonutComponent implements OnInit {
public gridApi:Promise<GridReadyEvent>;
//rowData=[];
 d3: any;
 name = 'Angular 5';
  public donutChartData = [{
        id: 0, // number
        label: 'Oustanding',  // string
        value: 1250,  // number
        color: '#ccc' // string,
       // iconImage: 'https://avatars.discourse.org/v2/letter/a/a8b319/45.png' // string
    }, {
        id: 1, // number
        label: 'Peding Validation',  // string
        value: 870,  // number
        color: '#DB6E00'  // string,
       // iconImage: 'https://avatars.discourse.org/v2/letter/a/a8b319/45.png' // string
    },
    {
            id: 3, // number
            label: 'Matured',  // string
            value: 5293,  // number
            color: '#31317A'  // string,
          //  iconImage: 'https://avatars.discourse.org/v2/letter/a/a8b319/45.png' // string
        },
        {
                    id: 4, // number
                    label: 'Validated',  // string
                    value: 8221,  // number
                    color: '#77B300'  // string,
                   // iconImage: 'https://avatars.discourse.org/v2/letter/a/a8b319/45.png' // string
                },
                {
                                    id: 4, // number
                                    label: 'Reversed',  // string
                                    value: 1100,  // number
                                    color: '#B30000'  // string,
                                   // iconImage: 'https://avatars.discourse.org/v2/letter/a/a8b319/45.png' // string
                                }
]

public pieChartData = [{
    id: 0,
    label: 'Derivatives',
    value: 50,
    color: '#520000',
  }, {
    id: 1,
    label: 'Bonds',
    value: 20,
    color: '#053B00',
  }, {
    id: 2,
    label: 'Swaps',
    value: 30,
    color: '#750000',
  },
  {
      id: 3,
      label: 'Cash',
      value: 40,
      color: '#001E52',
    },
    {
        id: 4,
        label: 'Equities',
        value: 80,
        color: '#524100',
      }]

    columnDefs = [
           {headerName: 'FundId', field: 'fundid',sortable: true, filter: true},
           {headerName: 'navAmount', field: 'navAmount',sortable: true, filter: true},
           {headerName: 'navDate', field: 'navDate',sortable: true, filter: true},
           {headerName: 'variation', field: 'variation',sortable: true, filter: true},
       ];

       columnDefs1 = [
               {headerName: 'Make', field: 'make', sortable: true, filter: true},
               {headerName: 'Model', field: 'model', sortable: true, filter: true},
               {headerName: 'Price', field: 'price', sortable: true, filter: true}
           ];

           rowData=[{"fundid":"SBIEQ1","navAmount":1249440.0,"navDate":"2019-10-01","variation":0},{"fundid":"SBIEQ2","navAmount":194672.11,"navDate":"2019-10-01","variation":0},{"fundid":"SBIEQ3","navAmount":14411.76,"navDate":"2019-10-01","variation":0},{"fundid":"SBIEQ4","navAmount":7194537.5,"navDate":"2019-10-01","variation":1},{"fundid":"SBIEQ5","navAmount":1010000.0,"navDate":"2019-10-01","variation":1},{"fundid":"SBIEQ6","navAmount":603000.0,"navDate":"2019-10-01","variation":1},{"fundid":"SBIEQ7","navAmount":4050250.0,"navDate":"2019-10-01","variation":1},{"fundid":"SBIEQ8","navAmount":13538.16,"navDate":"2019-10-01","variation":1},{"fundid":"SBIEQ9","navAmount":7800000.0,"navDate":"2019-10-01","variation":1},{"fundid":"SBIEQ10","navAmount":5125.0,"navDate":"2019-10-01","variation":1},{"fundid":"SBIEQ11","navAmount":101250.0,"navDate":"2019-10-01","variation":0},{"fundid":"SBIEQ12","navAmount":1100000.0,"navDate":"2019-10-01","variation":0},{"fundid":"SBIEQ13","navAmount":24000.0,"navDate":"2019-10-01","variation":0},{"fundid":"SBIEQ14","navAmount":235071.36,"navDate":"2019-10-01","variation":1},{"fundid":"SBIEQ15","navAmount":99000.0,"navDate":"2019-10-01","variation":1},{"fundid":"SBIEQ16","navAmount":1980000.0,"navDate":"2019-10-01","variation":1},{"fundid":"SBIEQ17","navAmount":900000.0,"navDate":"2019-10-01","variation":1},{"fundid":"SBIEQ18","navAmount":7845501.73,"navDate":"2019-10-01","variation":2},{"fundid":"SBIEQ19","navAmount":28200.0,"navDate":"2019-10-01","variation":2},{"fundid":"SBIEQ20","navAmount":8254959.93,"navDate":"2019-10-01","variation":2},{"fundid":"SBIEQ1","navAmount":75857.12,"navDate":"2019-10-02","variation":0},{"fundid":"SBIEQ2","navAmount":900000.0,"navDate":"2019-10-02","variation":0},{"fundid":"SBIEQ3","navAmount":456910.96,"navDate":"2019-10-02","variation":0},{"fundid":"SBIEQ4","navAmount":8600.0,"navDate":"2019-10-02","variation":1},{"fundid":"SBIEQ5","navAmount":16.0,"navDate":"2019-10-02","variation":1},{"fundid":"SBIEQ6","navAmount":1111.0,"navDate":"2019-10-02","variation":1},{"fundid":"SBIEQ7","navAmount":2750000.0,"navDate":"2019-10-02","variation":1},{"fundid":"SBIEQ8","navAmount":366937.5,"navDate":"2019-10-02","variation":1},{"fundid":"SBIEQ9","navAmount":6666666.67,"navDate":"2019-10-02","variation":1},{"fundid":"SBIEQ10","navAmount":890000.0,"navDate":"2019-10-02","variation":1},{"fundid":"SBIEQ11","navAmount":720000.0,"navDate":"2019-10-02","variation":0},{"fundid":"SBIEQ12","navAmount":58138.75,"navDate":"2019-10-02","variation":0},{"fundid":"SBIEQ13","navAmount":194000.0,"navDate":"2019-10-02","variation":0},{"fundid":"SBIEQ14","navAmount":9400.0,"navDate":"2019-10-02","variation":1},{"fundid":"SBIEQ15","navAmount":926550.0,"navDate":"2019-10-02","variation":1},{"fundid":"SBIEQ16","navAmount":64000.0,"navDate":"2019-10-02","variation":1},{"fundid":"SBIEQ17","navAmount":11600.0,"navDate":"2019-10-02","variation":1},{"fundid":"SBIEQ18","navAmount":46574.97,"navDate":"2019-10-02","variation":2},{"fundid":"SBIEQ19","navAmount":175066.75,"navDate":"2019-10-02","variation":2},{"fundid":"SBIEQ20","navAmount":980000.0,"navDate":"2019-10-02","variation":2},{"fundid":"SBIEQ1","navAmount":2.406621688E7,"navDate":"2019-10-03","variation":0},{"fundid":"SBIEQ2","navAmount":1140996.7,"navDate":"2019-10-03","variation":0},{"fundid":"SBIEQ3","navAmount":27500.0,"navDate":"2019-10-03","variation":0},{"fundid":"SBIEQ4","navAmount":1185122.12,"navDate":"2019-10-03","variation":1},{"fundid":"SBIEQ5","navAmount":51996.0,"navDate":"2019-10-03","variation":1},{"fundid":"SBIEQ6","navAmount":33333.33,"navDate":"2019-10-03","variation":1},{"fundid":"SBIEQ7","navAmount":13600.0,"navDate":"2019-10-03","variation":-1},{"fundid":"SBIEQ8","navAmount":1980000.0,"navDate":"2019-10-03","variation":1},{"fundid":"SBIEQ9","navAmount":-7615.34,"navDate":"2019-10-03","variation":1},{"fundid":"SBIEQ10","navAmount":1.02E7,"navDate":"2019-10-03","variation":1},{"fundid":"SBIEQ11","navAmount":1.02E7,"navDate":"2019-10-03","variation":0},{"fundid":"SBIEQ12","navAmount":6316.02,"navDate":"2019-10-03","variation":0},{"fundid":"SBIEQ13","navAmount":10890.0,"navDate":"2019-10-03","variation":0},{"fundid":"SBIEQ14","navAmount":27972.03,"navDate":"2019-10-03","variation":1},{"fundid":"SBIEQ15","navAmount":85333.33,"navDate":"2019-10-03","variation":-1},{"fundid":"SBIEQ16","navAmount":196000.0,"navDate":"2019-10-03","variation":1},{"fundid":"SBIEQ17","navAmount":383269.27,"navDate":"2019-10-03","variation":1},{"fundid":"SBIEQ18","navAmount":160000.0,"navDate":"2019-10-03","variation":2},{"fundid":"SBIEQ19","navAmount":12562.81,"navDate":"2019-10-03","variation":2},{"fundid":"SBIEQ20","navAmount":1089642.16,"navDate":"2019-10-03","variation":2},{"fundid":"SBIEQ1","navAmount":398000.0,"navDate":"2019-10-04","variation":0},{"fundid":"SBIEQ2","navAmount":986214.29,"navDate":"2019-10-04","variation":1},{"fundid":"SBIEQ3","navAmount":113636.36,"navDate":"2019-10-04","variation":1},{"fundid":"SBIEQ4","navAmount":0.0,"navDate":"2019-10-04","variation":1},{"fundid":"SBIEQ5","navAmount":10525.0,"navDate":"2019-10-04","variation":-1},{"fundid":"SBIEQ6","navAmount":122500.01,"navDate":"2019-10-04","variation":1},{"fundid":"SBIEQ7","navAmount":998570.0,"navDate":"2019-10-04","variation":1},{"fundid":"SBIEQ8","navAmount":2991506.85,"navDate":"2019-10-04","variation":1},{"fundid":"SBIEQ9","navAmount":2423.08,"navDate":"2019-10-04","variation":0},{"fundid":"SBIEQ10","navAmount":125984.25,"navDate":"2019-10-04","variation":1},{"fundid":"SBIEQ11","navAmount":2082820.0,"navDate":"2019-10-04","variation":0},{"fundid":"SBIEQ12","navAmount":1026061.64,"navDate":"2019-10-04","variation":0},{"fundid":"SBIEQ13","navAmount":9842.31,"navDate":"2019-10-04","variation":1},{"fundid":"SBIEQ14","navAmount":190000.0,"navDate":"2019-10-04","variation":2},{"fundid":"SBIEQ15","navAmount":7268400.0,"navDate":"2019-10-04","variation":2},{"fundid":"SBIEQ16","navAmount":175066.75,"navDate":"2019-10-04","variation":2},{"fundid":"SBIEQ17","navAmount":980000.0,"navDate":"2019-10-04","variation":2},{"fundid":"SBIEQ18","navAmount":2.406621688E7,"navDate":"2019-10-04","variation":2},{"fundid":"SBIEQ19","navAmount":1140996.7,"navDate":"2019-10-04","variation":2},{"fundid":"SBIEQ20","navAmount":27500.0,"navDate":"2019-10-04","variation":2},{"fundid":"SBIEQ1","navAmount":1185122.12,"navDate":"2019-10-04","variation":2},{"fundid":"SBIEQ2","navAmount":51996.0,"navDate":"2019-10-04","variation":0},{"fundid":"SBIEQ3","navAmount":33333.33,"navDate":"2019-10-04","variation":0},{"fundid":"SBIEQ4","navAmount":13600.0,"navDate":"2019-10-04","variation":2},{"fundid":"SBIEQ5","navAmount":1980000.0,"navDate":"2019-10-04","variation":2},{"fundid":"SBIEQ6","navAmount":-7615.34,"navDate":"2019-10-05","variation":0},{"fundid":"SBIEQ7","navAmount":1.02E7,"navDate":"2019-10-05","variation":2},{"fundid":"SBIEQ8","navAmount":1.02E7,"navDate":"2019-10-05","variation":0},{"fundid":"SBIEQ9","navAmount":6316.02,"navDate":"2019-10-05","variation":0},{"fundid":"SBIEQ10","navAmount":10890.0,"navDate":"2019-10-05","variation":1},{"fundid":"SBIEQ11","navAmount":27972.03,"navDate":"2019-10-05","variation":0},{"fundid":"SBIEQ12","navAmount":85333.33,"navDate":"2019-10-05","variation":0},{"fundid":"SBIEQ13","navAmount":196000.0,"navDate":"2019-10-05","variation":1},{"fundid":"SBIEQ14","navAmount":383269.27,"navDate":"2019-10-05","variation":0},{"fundid":"SBIEQ15","navAmount":160000.0,"navDate":"2019-10-05","variation":2},{"fundid":"SBIEQ16","navAmount":12562.81,"navDate":"2019-10-05","variation":2},{"fundid":"SBIEQ17","navAmount":366937.5,"navDate":"2019-10-05","variation":2},{"fundid":"SBIEQ18","navAmount":6666666.67,"navDate":"2019-10-05","variation":2},{"fundid":"SBIEQ19","navAmount":890000.0,"navDate":"2019-10-05","variation":2},{"fundid":"SBIEQ20","navAmount":720000.0,"navDate":"2019-10-05","variation":2}]



  constructor( private dataService: DbserviceService, private http: HttpClient) { }

  ngOnInit() {
    //this.rowData.push( this.http.get('https://api.myjson.com/bins/15psn9'));

  }



}
