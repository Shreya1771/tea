import { Component, OnDestroy, OnInit } from '@angular/core';
import { Subject, Subscription } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { Router } from '@angular/router';
import { DbserviceService } from '../dbservice.service';
import { HttpClient } from '@angular/common/http';

import { SpeechService } from '../../app/lib';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
   msg = 'Speaknow';
      comment = '';
      context = '';
      subscription = Subscription.EMPTY;
      good: any;
      pizzas: any[] = [
          'Sicilienne'
      ];
      started = false;

      private _destroyed = new Subject<void>();

      constructor(
      public speech: SpeechService,
      private dataService: DbserviceService,
      public router: Router) { }

      ngOnInit(): void {
          this.speech.start();
          this.speech.message.pipe(
              takeUntil(this._destroyed)
          ).subscribe(msg => this.msg = msg.message);
          this.speech.context.pipe(
              takeUntil(this._destroyed)
          ).subscribe(context =>  this.context = context);
          this.good = {message: 'Try me!'};
          this.speech.started.pipe(
              takeUntil(this._destroyed)
          ).subscribe(started => this.started = started);
      }

      ngOnDestroy(): void {
          this._destroyed.next();
          this._destroyed.complete();
          this.subscription.unsubscribe();
      }

      toggleVoiceRecognition(): void {
          if (this.started) {
              this.speech.stop();
          } else {
              this.speech.start();
          }
      }

      navigateToDashboard():void {


        this.dataService.sendGetRequest(this.msg).toPromise().then((data: string)=>{
                 this.router.navigate(['/dashboard'], { queryParams: { query: this.msg }, skipLocationChange: true } );
              })
      }


      recordStart(): void {
          this.subscription = this.speech.message.subscribe(msg => {
              this.comment += msg.message + '\n';
          });
      }

      recordStop(): void {
          this.subscription.unsubscribe();
      }

      hello(): void {
          console.log('hello');
      }

}
